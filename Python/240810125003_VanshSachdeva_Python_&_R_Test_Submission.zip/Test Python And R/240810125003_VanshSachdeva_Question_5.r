#Q5. Create a function in R and accept the data through two arguments.
# Function in R
calculate_sum <- function(a, b) {
  return(a + b)
}

# Example usage
result <- calculate_sum(10, 20)
print(result)
